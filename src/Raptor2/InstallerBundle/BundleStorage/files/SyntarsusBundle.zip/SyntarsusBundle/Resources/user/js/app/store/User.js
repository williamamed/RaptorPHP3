Ext.define('GestUser.store.User', {
    extend: 'Ext.data.Store',
    model: 'GestUser.model.UserModel'
});