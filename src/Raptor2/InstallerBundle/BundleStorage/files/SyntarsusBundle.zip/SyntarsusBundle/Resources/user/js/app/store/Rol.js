Ext.define('GestUser.store.Rol', {
    extend: 'Ext.data.Store',
    model: 'GestUser.model.RolModel'
    
});