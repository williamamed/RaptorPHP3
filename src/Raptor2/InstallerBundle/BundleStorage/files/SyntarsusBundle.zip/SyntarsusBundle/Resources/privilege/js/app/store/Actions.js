Ext.define('GestPrivilege.store.Actions', {
    extend: 'Ext.data.Store',
    model: 'GestPrivilege.model.ActionsModel'
   
    
});